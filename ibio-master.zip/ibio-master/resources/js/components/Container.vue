<template>
    <div class="p-5 w-full sm:w-10/12 md:w-8/12 xl:w-7/12">
        <slot></slot>
    </div>
</template>
