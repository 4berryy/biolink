import Vue from "vue";
import PortalVue from 'portal-vue';

Vue.use(PortalVue);
