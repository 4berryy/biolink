import Vue from "vue";
import ClickOutside from 'vue-click-outside';

Vue.directive('click-outside', ClickOutside);
