# IBio

IBio is a free bio link generator for social media like Instagram, TikTok, etc

You can register and get your link and share it on your social media.

The master branch is available on https://ibio.link

Sample link: https://ibio.link/saeedvaziry

## Installation

1) Install dependencies
```shell
# development
composer install

# production
composer install --no-dev
```

2) Create `.env` from `.env.example` and fill it according to your configs

3) Generate key

```shell
php artisan key:generate
```

4) Run the migrations

```shell
php artisan migrate
```

## What technologies used?

### Back-End

The back-end has been developed with [Laravel framework 8](https://github.com/laravel/laravel)

### Database

Database is Mysql or Mariadb

### Front-End

The front-end has been developed with [Vue.js 2](https://github.com/vuejs/vue), [Inertia.js](https://github.com/inertiajs/inertia), and [Tailwindcss 2](https://tailwindcss.com/)

## Credits

**Charts** 

[Chart.js](https://www.chartjs.org/) with [Vue Charts](https://vue-chartjs.org/)

**Icons**

[Fontawesome](https://fontawesome.com/) and [FlatIcon](https://www.flaticon.com/)

**Other**

Two-factor authentication by [pragmarx](https://packagist.org/packages/pragmarx/google2fa-laravel)

Front-End routes by [tighten](https://github.com/tighten/ziggy)

IP to location package by myself :) [saeedvaziry](https://github.com/saeedvaziry/ip2location)

User-Agent by [jenssegers](https://github.com/jenssegers/agent)

## Security

In case you see any security issues please send it to me directly at (sa.vaziry@gmail.com) or create an issue

## License

The source code is licensed under The MIT License (MIT).
